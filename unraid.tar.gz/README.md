# franz-recipe-unraid

This is a recipe for [Unraid](unraid.com) that provides access to the dashboard.
